# globaltradeanalysis
The objective of the project was to create innovative and interactive Tableau dashboards that focus on potential commodities, countries, year, trade amount and quantity.  The client wanted to launch a new business unit, focusing on global trade and logistics, majorly in the countries such as USA, Canada and Australia  The dataset provided by the client contained 59090 observations of 10 variables.  The client insisted the data to be cleaned using Excel or R. The Dataset contained missing values and was cleaned using the R programming language.  Tableau dashboards were created from the cleaned dataset.

To view the Tableau dashboards, visit my profile: https://goo.gl/Kw9Tja
